# Fameweb GTM & LinkedIn Lead Generation --- Product Requirements Document

## 1. Purpose

Build the next version of Fameweb's GTM / LinkedIn lead-generation
product as a multi-user-ready application while preserving the useful
existing functionality.

The PRD is the single product-level source of truth. Technical
implementation details belong in the supporting Markdown documents.

## 2. Core User Flow

1.  Landing page
2.  Sign up / Log in
3.  Optional LinkedIn connection through LinkedIn OIDC
4.  LinkedIn profile intake through upload/paste
5.  Company website input and company-data extraction/review
6.  ICP onboarding
7.  Optional profile optimization
8.  Dashboard
9.  GTM Research
10. Leads / qualification
11. Connect & Message
12. Follow-up tracking and scheduled outreach tasks
13. Settings

## 3. Authentication

Fameweb authentication uses email/phone + password with secure
server-side sessions.

LinkedIn connection is separate and uses the supported OIDC flow.
Fameweb must not store LinkedIn passwords, browser cookies, or a
persistent LinkedIn automation session.

## 4. LinkedIn Profile

The user's own LinkedIn profile can be supplied through an upload (for
example, LinkedIn PDF/data export) or pasted content. The information is
parsed and structured in the background.

## 5. Company + ICP

The user provides a company website. Fameweb extracts company
information, lets the user review/edit it, and stores the reviewed data.

The user defines an ICP containing target customer, company size,
revenue range, roles, industry, location, keywords, exclusions, signals
and tone.

## 6. GTM Research

Research starts with the global profile database. Profiles are qualified
against the user's ICP. Additional permitted discovery/enrichment can be
used where required.

Global/shared facts are stored separately from user-specific
qualification.

## 7. Outreach

Each user/lead pair has one outreach thread.

V1 uses a ManualExecutor: - Fameweb generates drafts. - The user
executes the LinkedIn action. - The user confirms the action in
Fameweb. - Replies can be pasted by the user. - Follow-ups are generated
using conversation context and scheduled as user tasks.

The architecture keeps outreach behind an OutreachExecutor interface so
a future approved executor can be introduced without changing the core
thread model.

## 8. Data Model

The approved architecture contains exactly 8 tables: 1. user_table 2.
users_company_details 3. users_icp 4. users_linkedin_details 5.
global_profiles 6. users_profiles 7. research_jobs 8.
connect_and_message

No additional table is required by the current architecture review.

## 9. Product Principles

-   Keep the implementation simple.
-   Do not add tables without a concrete requirement.
-   Keep global profile facts separate from user-specific qualification.
-   Keep conversation history append-only.
-   Do not overwrite templates/history with rendered or generated
    output.
-   Preserve existing useful UI/functionality where possible.
-   Build SQLite-compatible code now while keeping a clean migration
    path to PostgreSQL.
-   Existing LinkedIn Playwright/session automation is frozen and must
    not be extended.

## 10. Definition of Done

The product should support the complete flow from account creation
through onboarding, research, lead qualification and tracked outreach
tasks, with persistent job state, secure authentication, clear ownership
of data, and tests for authorization and state transitions.
